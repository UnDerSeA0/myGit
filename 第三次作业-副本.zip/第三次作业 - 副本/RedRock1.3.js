
window.onload = function() {
    var button1 = document.getElementsByClassName("box-button");
    button1.onclick = function () {{
        var time;
        var distance;
        if (!time) time = 500;
        if (!distance) distance = 5;
        var oralstyle = button1.style.cssText;
        var startTime = (new Date()).getTime();
        animated();


    function animated() {
        var now = (new Date()).getTime();
        var elapsed = now - startTime;
        var fraction = elapsed / time;
        if (fraction < 1) {
            var x = distance * Math.sin(fraction * 4 * Math.PI);
            button1.style.left = x + "px";
            setTimeout(animated, Math.min(25, time - elapsed));
        }
        else {
            button1.style.cssText = oralstyle;
        }

    }
    }
};};
