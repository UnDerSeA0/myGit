window.onload=function () {
    var aqiData = [
        ["北京", 90],
        ["上海", 50],
        ["福州", 10],
        ["广州", 50],
        ["成都", 90],
        ["西安", 100]
    ];
    var Ranknum = new Array("一", "二", "三", "四", "五", "六");
    var ChangeData = ["", 0];
    var ul = document.getElementsByTagName("ul")[0];
    for (var i = 0; i < aqiData.length - 1; i++) {
        for (var j = i + 1; j < aqiData.length; j++) {
            if (aqiData[i][1] < aqiData[j][1]) {
                ChangeData = aqiData[i];
                aqiData[i] = aqiData[j];
                aqiData[j] = ChangeData;
            }
        }
    }
    /*按得分排序*/
    for (var i = 0; i < aqiData.length; i++) {
        if (aqiData[i][1] >= 60) {
            var li = document.createElement("li");
            var text = document.createTextNode("第" + Ranknum[i] + "名：" + aqiData[i]);
            li.appendChild(text);
            ul.appendChild(li);
        }
    }
    /*显示*/
};
